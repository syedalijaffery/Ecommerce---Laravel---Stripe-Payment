
    <div class="row">

        <div class="col-lg-2">

            &nbsp; <h5 class="">Categories</h5>
            <div class="list-group">
                @foreach($category as $cat)
                    <a href="/category/{{$cat['category']}}" class="list-group-item"> {{ $cat['category']}}</a>
                @endforeach
            </div>

        </div>

            <!-- /.col-lg-3 -->