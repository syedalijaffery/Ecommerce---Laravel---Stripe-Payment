

<!-- header -->
<div class="agileits_header">


    <div class="product_list_header">
        <form action="#" method="post" class="last">
            <fieldset>
                <input type="hidden" name="cmd" value="_cart" />
                <input type="hidden" name="display" value="1" />
                <input type="submit" name="submit" value="View your cart" class="button" />
            </fieldset>
        </form>
    </div>
    <div class="w3l_header_right">
        <ul>
           <li> <a class="navbar-brand" href="{{ route('product.index') }}">Fresh Veg</a></li>
            <li class="dropdown profile_details_drop">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user" aria-hidden="true"></i><span class="caret"></span></a>
                <div class="mega-dropdown-menu">
                    <div class="w3ls_vegetables">
                        <ul class="dropdown-menu drp-mnu">

                            @if(Auth::check())
                                <li><a href="{{ route('user.profile') }}">{{Auth::user()->name}}</a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="{{ route('user.logout') }}">Logout</a></li>
                            @else
                                <li><a href="{{ route('user.signup') }}">Signup</a></li>
                                <li><a href="{{ route('user.signin') }}">Signin</a></li>
                            @endif
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
    <div class="w3l_header_right1">

            <a href="{{ route('product.shoppingCart') }}">
                <i class="fa fa-shopping-cart" aria-hidden="true"></i> Shopping Cart
                <span class="badge">{{ Session::has('cart') ? Session::get('cart')->totalQty : '' }}</span>
            </a>

    </div>
    <div class="clearfix"> </div>
</div>