@extends('layouts.master')
@section('content')

<div class="card mt-4">
    <a href="/product/{{$product->id}}"> <img src="{{ $product->imagePath }}" alt="..." class="img-responsive">
    <div class="card-block">
        <h3 class="card-title">{{$product->name}}</h3>
        <h4>&#x20a8; {{$product->price}}</h4>
        <h6>
           {{$product->quantity}}&nbsp;In&nbsp;Stock
        </h6>
        <p class="card-text">{{$product->description}}</p>
        <a href="{{ route('product.addToCart', ['id' => $product->id]) }}"
           class="btn btn-success pull-right" role="button">Add to Cart</a>
        <hr>

    </div>
</div>
<!-- /.card -->

<div class="card card-outline-secondary my-5">
    <div class="card-header">
        Product Reviews
    </div>
    <div class="card-block">
    @if($product->reviews->count('review'))
        @foreach($product->reviews as $review)

            <h6>{{$review->user->name}}</h6>

        <p>{{$review->review}} </p>

        <small class="text-muted">{{$review->created_at->toFormattedDateString()}}</small>
        <hr>
        @endforeach
        @endif
            <div class="form-group">

               <form method="post" action="/review/{{$product->id}}">
                   {{csrf_field()}}
                   <div class="input-group">
                   <span class="input-group-addon" id="basic-addon1">Review</span>
                   <input type="text" class="form-control" placeholder="review" name="review" id="review" aria-describedby="basic-addon1">
                   </div>
            </div>
        <input type="submit" class="btn btn-success" value="Leave a Review">
            </form>
            @if(Session::get('errors'))
                <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5>There were errors while submitting this review:</h5>
                    <ul>
                    @foreach($errors->all() as $message)
                      <li>  {{$message}}  </li>
                    @endforeach
                    </ul>
                </div>
            @endif
    </div>
</div>
<!-- /.card -->


    @endsection