<center><h2>Admin Panel</h2></center>
<hr>

<html>

@include('admin.nav')
<body>


@yield('content')

</body>
</html>